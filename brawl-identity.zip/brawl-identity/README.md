# Brawl Identity

Brawl Identity is an unofficial, fan-made Brawl Stars personality quiz built for
community entertainment. Users answer 8 playstyle questions and get matched with a
real Brawl Stars Brawler based on their aggression, strategy, teamwork, and clutch
ability scores.

This project is not an official Supercell website or application, and it is not
affiliated with, endorsed by, or officially connected to Supercell or Brawl Stars in
any way. All Brawler names and Brawl Stars trademarks belong to Supercell.

## Features

- Dark, futuristic gaming UI with purple and blue gradients
- Glassmorphism cards with subtle gradient borders
- Scroll reveal animations (bottom to top) powered by Framer Motion
- 8 question personality and playstyle quiz
- Trait-based scoring system across 18 real Brawlers in 5 classes
- Result page with a downloadable PNG identity card
- Share result link with the Web Share API and clipboard fallback
- Mobile-first responsive layout

## Getting started

```bash
npm install
npm run dev
```

Then open the local URL that Vite prints in your terminal.

To build for production:

```bash
npm run build
npm run preview
```

## Project structure

```
src/
  data/
    brawlers.js       Brawler roster, classes, playstyle text, trait profiles
    questions.js       The 8 quiz questions and their trait point values
  utils/
    scoring.js         Aggregates answers and finds the closest matching Brawler
  components/
    Header.jsx
    Hero.jsx
    ClassesOverview.jsx
    QuizSection.jsx
    QuestionCard.jsx
    ProgressBar.jsx
    ResultSection.jsx
    ResultCard.jsx
    StatBar.jsx
    ShareBar.jsx
    Footer.jsx
    RevealSection.jsx
  App.jsx
  main.jsx
  index.css
```

## How scoring works

Each answer contributes points to four traits: aggression, strategy, teamwork, and
clutch ability. After all 8 questions are answered, the totals are normalized to a
0 to 100 scale and compared against each Brawler's trait profile. The Brawler with
the closest overall profile becomes the result.

## Updating the Brawler roster

To add, remove, or adjust a Brawler, edit `src/data/brawlers.js`. Each entry needs
an id, name, class, playstyle label, short description, and a trait object with
aggression, strategy, teamwork, and clutch values from 0 to 100.
