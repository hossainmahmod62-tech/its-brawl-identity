import { useState } from 'react';
import { QUESTIONS } from '../data/questions.js';
import ProgressBar from './ProgressBar.jsx';
import QuestionCard from './QuestionCard.jsx';

export default function QuizSection({ onComplete }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState([]);

  function handleAnswer(optionIndex) {
    const question = QUESTIONS[currentIndex];
    const nextAnswers = [...answers, { questionId: question.id, optionIndex }];
    setAnswers(nextAnswers);

    if (currentIndex + 1 < QUESTIONS.length) {
      setCurrentIndex(currentIndex + 1);
    } else {
      onComplete(nextAnswers);
    }
  }

  return (
    <section className="flex min-h-screen flex-col items-center justify-center px-5 py-24">
      <ProgressBar current={currentIndex} total={QUESTIONS.length} />
      <QuestionCard question={QUESTIONS[currentIndex]} onAnswer={handleAnswer} />
    </section>
  );
}
