import { forwardRef } from 'react';
import StatBar from './StatBar.jsx';

const ResultCard = forwardRef(function ResultCard({ brawler, stats }, ref) {
  return (
    <div
      ref={ref}
      className="glass-card mx-auto w-full max-w-md overflow-hidden p-8"
      style={{ background: 'linear-gradient(160deg, rgba(15,15,36,0.95), rgba(10,10,22,0.98))' }}
    >
      <p className="text-center text-xs font-semibold uppercase tracking-[0.3em] text-white/40">
        Your Brawler Identity
      </p>

      <h2 className="mt-4 text-center font-display text-4xl font-bold gradient-text sm:text-5xl">
        {brawler.name}
      </h2>

      <div className="mt-3 flex items-center justify-center gap-2">
        <span className="rounded-full border border-violet-400/40 bg-violet-500/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-violet-300">
          {brawler.class}
        </span>
      </div>

      <p className="mt-4 text-center text-sm font-medium text-white/70">
        {brawler.playstyle}
      </p>

      <p className="mt-3 text-center text-sm leading-relaxed text-white/50">
        {brawler.description}
      </p>

      <div className="mt-8 flex flex-col gap-4">
        <StatBar label="Aggression" value={stats.aggression} />
        <StatBar label="Strategy" value={stats.strategy} />
        <StatBar label="Teamwork" value={stats.teamwork} />
        <StatBar label="Clutch Ability" value={stats.clutch} />
      </div>

      <div className="mt-8 border-t border-white/10 pt-4 text-center text-[10px] uppercase tracking-widest text-white/25">
        Brawl Identity: Fan-Made Quiz
      </div>
    </div>
  );
});

export default ResultCard;
