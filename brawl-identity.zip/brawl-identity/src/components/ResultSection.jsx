import { useRef } from 'react';
import { motion } from 'framer-motion';
import ResultCard from './ResultCard.jsx';
import ShareBar from './ShareBar.jsx';

export default function ResultSection({ result, onRetake }) {
  const cardRef = useRef(null);

  return (
    <section className="flex min-h-screen flex-col items-center justify-center px-5 py-24">
      <motion.div
        initial={{ opacity: 0, y: 60 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="w-full"
      >
        <ResultCard ref={cardRef} brawler={result.brawler} stats={result.stats} />
        <ShareBar cardRef={cardRef} brawler={result.brawler} onRetake={onRetake} />
      </motion.div>
    </section>
  );
}
