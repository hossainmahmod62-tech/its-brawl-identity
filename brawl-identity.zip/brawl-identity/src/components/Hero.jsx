import { motion } from 'framer-motion';
import { Swords } from 'lucide-react';

export default function Hero({ onStart }) {
  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center px-5 pt-24 text-center">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="flex max-w-2xl flex-col items-center"
      >
        <div className="glass-card mb-6 flex items-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-widest text-white/60">
          <Swords className="h-4 w-4 text-violet-400" />
          8 Questions. One Brawler Identity.
        </div>

        <h1 className="font-display text-5xl font-bold leading-tight sm:text-6xl md:text-7xl">
          Which <span className="gradient-text">Brawler</span>
          <br />
          Matches Your Playstyle?
        </h1>

        <p className="mt-6 max-w-lg text-base text-white/60 sm:text-lg">
          Answer a short set of personality and playstyle questions and discover which
          real Brawl Stars Brawler mirrors how you actually play.
        </p>

        <button onClick={onStart} className="btn-primary mt-10">
          Start The Quiz
        </button>

        <p className="mt-8 max-w-md text-xs leading-relaxed text-white/30">
          Brawl Identity is an unofficial fan-made project for entertainment purposes.
          Not affiliated with or endorsed by Supercell.
        </p>
      </motion.div>
    </section>
  );
}
