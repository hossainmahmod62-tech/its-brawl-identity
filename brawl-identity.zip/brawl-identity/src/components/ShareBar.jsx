import { useState } from 'react';
import html2canvas from 'html2canvas';
import { Download, Share2, Link2, Check } from 'lucide-react';

export default function ShareBar({ cardRef, brawler, onRetake }) {
  const [copied, setCopied] = useState(false);

  function getShareUrl() {
    const url = new URL(window.location.href);
    url.searchParams.set('result', brawler.id);
    return url.toString();
  }

  function getShareText() {
    return `I got ${brawler.name} on Brawl Identity. Find your own Brawler match.`;
  }

  async function handleDownload() {
    if (!cardRef.current) return;
    try {
      const canvas = await html2canvas(cardRef.current, {
        backgroundColor: '#0a0a16',
        scale: 2,
        useCORS: true,
      });
      const link = document.createElement('a');
      link.download = `brawl-identity-${brawler.id}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (error) {
      console.error('Could not generate the card image.', error);
    }
  }

  async function handleShare() {
    const shareData = {
      title: 'Brawl Identity',
      text: getShareText(),
      url: getShareUrl(),
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (error) {
        // Share was cancelled or failed silently, no action needed.
      }
    } else {
      handleCopyLink();
    }
  }

  async function handleCopyLink() {
    try {
      await navigator.clipboard.writeText(getShareUrl());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Could not copy the link.', error);
    }
  }

  return (
    <div className="mx-auto mt-8 flex w-full max-w-md flex-col gap-3">
      <button onClick={handleDownload} className="btn-primary w-full">
        <Download className="h-4 w-4" />
        Download PNG Card
      </button>

      <div className="flex flex-col gap-3 sm:flex-row">
        <button onClick={handleShare} className="btn-secondary w-full">
          <Share2 className="h-4 w-4" />
          Share Your Result With Friends
        </button>

        <button onClick={handleCopyLink} className="btn-secondary w-full">
          {copied ? <Check className="h-4 w-4 text-electric-400" /> : <Link2 className="h-4 w-4" />}
          {copied ? 'Link Copied' : 'Copy Share Link'}
        </button>
      </div>

      <button
        onClick={onRetake}
        className="mt-2 text-center text-xs font-semibold uppercase tracking-widest text-white/40 transition-colors hover:text-white/70"
      >
        Retake The Quiz
      </button>
    </div>
  );
}
