export default function StatBar({ label, value }) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between text-xs font-semibold uppercase tracking-widest text-white/50">
        <span>{label}</span>
        <span className="text-white/80">{value}/100</span>
      </div>
      <div className="stat-bar-track">
        <div className="stat-bar-fill" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}
