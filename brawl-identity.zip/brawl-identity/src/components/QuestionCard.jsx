import { motion, AnimatePresence } from 'framer-motion';

export default function QuestionCard({ question, onAnswer }) {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={question.id}
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -40 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        className="glass-card mx-auto w-full max-w-xl p-6 sm:p-8"
      >
        <h3 className="mb-6 font-display text-xl font-semibold text-white sm:text-2xl">
          {question.text}
        </h3>

        <div className="flex flex-col gap-3">
          {question.options.map((option, index) => (
            <motion.button
              key={index}
              onClick={() => onAnswer(index)}
              whileHover={{ scale: 1.015 }}
              whileTap={{ scale: 0.98 }}
              className="group flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-5 py-4 text-left text-sm text-white/80 transition-colors duration-200 hover:border-violet-400/50 hover:bg-white/[0.07] hover:text-white sm:text-base"
            >
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-white/20 text-xs font-semibold text-white/50 group-hover:border-violet-400 group-hover:text-violet-300">
                {String.fromCharCode(65 + index)}
              </span>
              {option.label}
            </motion.button>
          ))}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
