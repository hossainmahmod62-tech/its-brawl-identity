import { BRAWLERS } from '../data/brawlers.js';
import { QUESTIONS } from '../data/questions.js';

const TRAIT_KEYS = ['aggression', 'strategy', 'teamwork', 'clutch'];

function getMaxPossible() {
  const max = { aggression: 0, strategy: 0, teamwork: 0, clutch: 0 };
  QUESTIONS.forEach((question) => {
    TRAIT_KEYS.forEach((trait) => {
      const highest = Math.max(...question.options.map((opt) => opt.points[trait] || 0));
      max[trait] += highest;
    });
  });
  return max;
}

// answers: array of { questionId, optionIndex }
export function calculateResult(answers) {
  const totals = { aggression: 0, strategy: 0, teamwork: 0, clutch: 0 };

  answers.forEach(({ questionId, optionIndex }) => {
    const question = QUESTIONS.find((q) => q.id === questionId);
    if (!question) return;
    const option = question.options[optionIndex];
    if (!option) return;
    TRAIT_KEYS.forEach((trait) => {
      totals[trait] += option.points[trait] || 0;
    });
  });

  const maxPossible = getMaxPossible();

  const normalized = {};
  TRAIT_KEYS.forEach((trait) => {
    const max = maxPossible[trait] || 1;
    normalized[trait] = Math.round((totals[trait] / max) * 100);
  });

  let bestBrawler = BRAWLERS[0];
  let bestDistance = Infinity;

  BRAWLERS.forEach((brawler) => {
    const distance = Math.sqrt(
      TRAIT_KEYS.reduce((sum, trait) => {
        const diff = (brawler.traits[trait] || 0) - normalized[trait];
        return sum + diff * diff;
      }, 0)
    );
    if (distance < bestDistance) {
      bestDistance = distance;
      bestBrawler = brawler;
    }
  });

  return {
    brawler: bestBrawler,
    stats: normalized,
  };
}
