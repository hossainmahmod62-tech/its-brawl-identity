import { useState } from 'react';
import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import ClassesOverview from './components/ClassesOverview.jsx';
import QuizSection from './components/QuizSection.jsx';
import ResultSection from './components/ResultSection.jsx';
import Footer from './components/Footer.jsx';
import { calculateResult } from './utils/scoring.js';

const VIEWS = {
  HOME: 'home',
  QUIZ: 'quiz',
  RESULT: 'result',
};

export default function App() {
  const [view, setView] = useState(VIEWS.HOME);
  const [result, setResult] = useState(null);

  function startQuiz() {
    setResult(null);
    setView(VIEWS.QUIZ);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function handleQuizComplete(answers) {
    const computed = calculateResult(answers);
    setResult(computed);
    setView(VIEWS.RESULT);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function retakeQuiz() {
    startQuiz();
  }

  return (
    <div className="min-h-screen">
      <Header />

      {view === VIEWS.HOME && (
        <>
          <Hero onStart={startQuiz} />
          <ClassesOverview onStart={startQuiz} />
        </>
      )}

      {view === VIEWS.QUIZ && <QuizSection onComplete={handleQuizComplete} />}

      {view === VIEWS.RESULT && result && (
        <ResultSection result={result} onRetake={retakeQuiz} />
      )}

      <Footer />
    </div>
  );
}
