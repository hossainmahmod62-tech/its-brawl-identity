// All names below are real Brawl Stars Brawlers, owned by Supercell.
// This file only stores flavor text and illustrative trait weights used
// to power an unofficial fan-made personality quiz.

export const BRAWLERS = [
  // Assassin
  {
    id: 'mortis',
    name: 'Mortis',
    class: 'Assassin',
    playstyle: 'Fast aggressive attacker',
    description:
      'You strike quickly, punish mistakes and disappear before anyone can react. Standing still is not in your vocabulary.',
    traits: { aggression: 90, strategy: 55, teamwork: 40, clutch: 85 },
  },
  {
    id: 'leon',
    name: 'Leon',
    class: 'Assassin',
    playstyle: 'Sneaky pick-off specialist',
    description:
      'You wait, vanish, then strike from an angle nobody expected. Patience is your weapon as much as your blades.',
    traits: { aggression: 85, strategy: 70, teamwork: 35, clutch: 90 },
  },
  {
    id: 'edgar',
    name: 'Edgar',
    class: 'Assassin',
    playstyle: 'Relentless brawler',
    description:
      'You dive straight into the chaos and only get stronger the harder the fight becomes. Retreat is rarely part of the plan.',
    traits: { aggression: 95, strategy: 45, teamwork: 30, clutch: 80 },
  },
  {
    id: 'crow',
    name: 'Crow',
    class: 'Assassin',
    playstyle: 'Poison hit-and-run duelist',
    description:
      'You chip away at opponents from range, then finish the job up close once the poison has done its work.',
    traits: { aggression: 80, strategy: 75, teamwork: 45, clutch: 75 },
  },

  // Tank
  {
    id: 'bull',
    name: 'Bull',
    class: 'Tank',
    playstyle: 'Front line brawler',
    description:
      'You lead every push, soak up the damage, and clear a path for everyone behind you.',
    traits: { aggression: 88, strategy: 40, teamwork: 65, clutch: 70 },
  },
  {
    id: 'el-primo',
    name: 'El Primo',
    class: 'Tank',
    playstyle: 'Close-range brawler',
    description:
      'You close the distance without hesitation and trade blows head on, confident you can outlast anyone.',
    traits: { aggression: 85, strategy: 45, teamwork: 70, clutch: 75 },
  },
  {
    id: 'frank',
    name: 'Frank',
    class: 'Tank',
    playstyle: 'Slow powerful controller',
    description:
      'You take your time, absorb pressure, and land the one hit that turns a fight completely around.',
    traits: { aggression: 75, strategy: 55, teamwork: 75, clutch: 80 },
  },
  {
    id: 'rosa',
    name: 'Rosa',
    class: 'Tank',
    playstyle: 'Bush-control defender',
    description:
      'You hold ground, shield your team, and outlast opponents through sheer sustain rather than burst damage.',
    traits: { aggression: 70, strategy: 50, teamwork: 85, clutch: 65 },
  },

  // Marksman
  {
    id: 'piper',
    name: 'Piper',
    class: 'Marksman',
    playstyle: 'Long range precision shooter',
    description:
      'You keep your distance and let precision do the talking. One well-placed shot is worth more than ten wild ones.',
    traits: { aggression: 40, strategy: 90, teamwork: 50, clutch: 85 },
  },
  {
    id: 'brock',
    name: 'Brock',
    class: 'Marksman',
    playstyle: 'High-damage sniper',
    description:
      'You control the map from afar, punishing anyone who steps into your line of sight.',
    traits: { aggression: 55, strategy: 85, teamwork: 45, clutch: 80 },
  },
  {
    id: 'bea',
    name: 'Bea',
    class: 'Marksman',
    playstyle: 'Calculated poke damage',
    description:
      'You play the long game, softening opponents up before landing the shot that seals the round.',
    traits: { aggression: 45, strategy: 88, teamwork: 40, clutch: 90 },
  },
  {
    id: 'belle',
    name: 'Belle',
    class: 'Marksman',
    playstyle: 'Tactical mark and burst',
    description:
      'You read the fight before it happens, lining up marks and converting them into decisive damage.',
    traits: { aggression: 50, strategy: 92, teamwork: 55, clutch: 78 },
  },

  // Support
  {
    id: 'poco',
    name: 'Poco',
    class: 'Support',
    playstyle: 'Team healer',
    description:
      'You keep everyone else standing, prioritizing the team\'s survival over your own kill count.',
    traits: { aggression: 30, strategy: 60, teamwork: 92, clutch: 55 },
  },
  {
    id: 'byron',
    name: 'Byron',
    class: 'Support',
    playstyle: 'Ranged healer and poker',
    description:
      'You balance healing and chip damage from a safe distance, always thinking two steps ahead of the fight.',
    traits: { aggression: 35, strategy: 80, teamwork: 85, clutch: 60 },
  },
  {
    id: 'pam',
    name: 'Pam',
    class: 'Support',
    playstyle: 'Area sustain provider',
    description:
      'You set up zones that keep your whole team topped up, turning drawn-out fights in your favor.',
    traits: { aggression: 40, strategy: 65, teamwork: 90, clutch: 50 },
  },

  // Controller
  {
    id: 'spike',
    name: 'Spike',
    class: 'Controller',
    playstyle: 'Area denial specialist',
    description:
      'You control space with area damage, forcing opponents into positions where they have no good options.',
    traits: { aggression: 60, strategy: 85, teamwork: 55, clutch: 82 },
  },
  {
    id: 'sandy',
    name: 'Sandy',
    class: 'Controller',
    playstyle: 'Vision and zone control',
    description:
      'You dictate how a fight unfolds by controlling vision and terrain before anyone else reacts.',
    traits: { aggression: 45, strategy: 90, teamwork: 60, clutch: 70 },
  },
  {
    id: 'tara',
    name: 'Tara',
    class: 'Controller',
    playstyle: 'Crowd manipulation specialist',
    description:
      'You group enemies together and punish bad positioning, turning disorganized opponents into easy targets.',
    traits: { aggression: 55, strategy: 88, teamwork: 50, clutch: 85 },
  },
];

export const CLASS_ORDER = ['Assassin', 'Tank', 'Marksman', 'Support', 'Controller'];

export function getBrawlerById(id) {
  return BRAWLERS.find((b) => b.id === id) || null;
}
