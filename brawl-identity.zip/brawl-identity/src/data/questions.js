export const QUESTIONS = [
  {
    id: 1,
    text: 'The match just started. What is your first move?',
    options: [
      { label: 'Push straight toward the enemy spawn', points: { aggression: 3, strategy: 0, teamwork: 0, clutch: 1 } },
      { label: 'Scout the bushes and map out the enemy positions', points: { aggression: 0, strategy: 3, teamwork: 1, clutch: 0 } },
      { label: 'Group up with teammates before advancing', points: { aggression: 0, strategy: 1, teamwork: 3, clutch: 0 } },
      { label: 'Hold your position and wait for an opening', points: { aggression: 0, strategy: 2, teamwork: 0, clutch: 3 } },
    ],
  },
  {
    id: 2,
    text: 'A teammate gets caught out and is losing a 1v1. What do you do?',
    options: [
      { label: 'Rush in immediately to turn it into a 2v1', points: { aggression: 3, strategy: 0, teamwork: 2, clutch: 1 } },
      { label: 'Flank the enemy from an angle they cannot see', points: { aggression: 1, strategy: 3, teamwork: 1, clutch: 1 } },
      { label: 'Retreat together and regroup as a team', points: { aggression: 0, strategy: 1, teamwork: 3, clutch: 0 } },
      { label: 'Wait for the exact moment to land a game-changing shot', points: { aggression: 1, strategy: 1, teamwork: 0, clutch: 3 } },
    ],
  },
  {
    id: 3,
    text: 'Which role do you naturally gravitate toward in a team game?',
    options: [
      { label: 'The one who dives in first and creates chaos', points: { aggression: 3, strategy: 0, teamwork: 1, clutch: 1 } },
      { label: 'The planner who calls out enemy movements', points: { aggression: 0, strategy: 3, teamwork: 1, clutch: 0 } },
      { label: 'The one keeping everyone alive and supported', points: { aggression: 0, strategy: 1, teamwork: 3, clutch: 1 } },
      { label: 'The closer who finishes fights at the right moment', points: { aggression: 1, strategy: 0, teamwork: 0, clutch: 3 } },
    ],
  },
  {
    id: 4,
    text: 'It is the final moments of the match and the score is close. What is your mindset?',
    options: [
      { label: 'Force the fight now, hesitation loses matches', points: { aggression: 3, strategy: 0, teamwork: 0, clutch: 2 } },
      { label: 'Reposition to control the safest zone on the map', points: { aggression: 0, strategy: 3, teamwork: 1, clutch: 1 } },
      { label: 'Stay close to teammates so no one gets isolated', points: { aggression: 0, strategy: 0, teamwork: 3, clutch: 1 } },
      { label: 'Stay calm and wait for the one play that decides it', points: { aggression: 0, strategy: 1, teamwork: 0, clutch: 3 } },
    ],
  },
  {
    id: 5,
    text: 'How do you feel about taking risks during a match?',
    options: [
      { label: 'Risks are worth it, playing safe rarely wins games', points: { aggression: 3, strategy: 1, teamwork: 0, clutch: 1 } },
      { label: 'Only if the numbers and positioning clearly favor me', points: { aggression: 0, strategy: 3, teamwork: 0, clutch: 1 } },
      { label: 'I would rather protect the team than gamble alone', points: { aggression: 0, strategy: 1, teamwork: 3, clutch: 0 } },
      { label: 'I save my risks for the moment that actually matters', points: { aggression: 1, strategy: 0, teamwork: 0, clutch: 3 } },
    ],
  },
  {
    id: 6,
    text: 'Your team is losing control of the match. How do you respond?',
    options: [
      { label: 'Go on the offensive and force a mistake out of them', points: { aggression: 3, strategy: 1, teamwork: 0, clutch: 1 } },
      { label: 'Adjust your positioning and rethink the approach', points: { aggression: 0, strategy: 3, teamwork: 0, clutch: 1 } },
      { label: 'Rally the team and coordinate a comeback together', points: { aggression: 0, strategy: 0, teamwork: 3, clutch: 1 } },
      { label: 'Stay patient, one good play can flip the whole match', points: { aggression: 0, strategy: 1, teamwork: 0, clutch: 3 } },
    ],
  },
  {
    id: 7,
    text: 'What feels the most satisfying to you in a match?',
    options: [
      { label: 'Diving in and taking down multiple enemies fast', points: { aggression: 3, strategy: 0, teamwork: 0, clutch: 1 } },
      { label: 'Outsmarting an opponent with better positioning', points: { aggression: 0, strategy: 3, teamwork: 0, clutch: 1 } },
      { label: 'Keeping the whole team alive through a tough fight', points: { aggression: 0, strategy: 0, teamwork: 3, clutch: 1 } },
      { label: 'Landing the exact shot that wins the match', points: { aggression: 0, strategy: 1, teamwork: 0, clutch: 3 } },
    ],
  },
  {
    id: 8,
    text: 'How would your teammates describe your playstyle?',
    options: [
      { label: 'Fearless and always first into the fight', points: { aggression: 3, strategy: 0, teamwork: 1, clutch: 0 } },
      { label: 'Calculated, always thinking a few steps ahead', points: { aggression: 0, strategy: 3, teamwork: 1, clutch: 0 } },
      { label: 'Reliable, always there to back the team up', points: { aggression: 0, strategy: 0, teamwork: 3, clutch: 1 } },
      { label: 'Clutch, quiet until the moment it counts', points: { aggression: 0, strategy: 0, teamwork: 0, clutch: 3 } },
    ],
  },
];
